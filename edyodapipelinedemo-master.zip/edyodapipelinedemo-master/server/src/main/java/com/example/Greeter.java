package com.example;

/**
 * This is a test class.
 * We are testing again
 */
public class Greeter {

  /**
   * This is a constructor.
   */
  public Greeter() {

  }
 public String greet(String someone) {
  //TODO: Add javadoc comment
    //return String.format("Hello ?, %s!", someone);
   return String.format("Hello There, %s!", someone);
  }
}
